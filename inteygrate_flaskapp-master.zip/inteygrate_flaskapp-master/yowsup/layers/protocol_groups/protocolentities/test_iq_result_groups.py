from yowsup.layers.protocol_iq.protocolentities.test_iq_result import ResultIqProtocolEntityTest

class GroupsResultIqProtocolEntityTest(ResultIqProtocolEntityTest):
    pass